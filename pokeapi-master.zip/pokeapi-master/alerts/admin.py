from django.contrib import admin

from .models import Alert

admin.site.register(Alert)
